package com.example.tubes_covid;

public interface FragmentListener {
    void changePage(int page,String input);
    void closeApplication();
}